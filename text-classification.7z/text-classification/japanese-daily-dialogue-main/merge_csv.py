# -*- coding: utf-8 -*-
import os
import glob

def merge_csv_files(input, output, num):
    file_list = glob.glob(os.path.join(input, 'corpus_*.csv'))

    #csvファイル存在確認
    if os.path.exists(output) == True:
        os.remove(output)

    #csvファイル読み込み
    with open(output, encoding='utf-8', mode='a') as list:
        for csv in file_list:
            with open(csv, encoding='utf-8') as f:
                lines = f.readlines()

            for a,b in enumerate(lines,1):
                if a > num:
                    break
                list.write(b)

def merge_csv_main():
    merge_csv_files('data/', 'data/list.csv', 100)

if __name__ == '__main__':
    merge_csv_main()