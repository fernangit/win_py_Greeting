# -*- coding: utf-8 -*-
import json

def read_json_file(input, output):
    #jsonファイル読み込み
    with open(input, encoding='utf-8') as f:
        j = json.load(f)

    #コーパスファイル作成
    with open(output, encoding='utf-8', mode='w') as f:
        for key in j:
            for u in key['utterances']:
                corpus = str(key['topic_id']) + (', ') + u['utterance'] + '\n'
                print(corpus)
                f.write(corpus)

def read_json_main():
    read_json_file('./data/topic1.json', 'data/corpus_Dailylife.csv')
    read_json_file('./data/topic2.json', 'data/corpus_Schoollife.csv')
    read_json_file('./data/topic3.json', 'data/corpus_Travel.csv')
    read_json_file('./data/topic4.json', 'data/corpus_Health.csv')
    read_json_file('./data/topic5.json', 'data/corpus_Entertainment.csv')

if __name__ == '__main__':
    read_json_main()