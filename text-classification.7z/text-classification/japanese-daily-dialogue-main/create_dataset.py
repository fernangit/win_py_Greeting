#【Huggingface Transformers】 日本語のテキスト分類を学習から推論までを実装する
#https://tt-tsukumochi.com/archives/4134
#Huggingface Transformers 入門 (12) -日本語のテキスト分類の学習
#https://note.com/npaka/n/n6df2be2a91c5

# -*- coding: utf-8 -*-
import os
import pandas as pd
import csv

def get_utter_list(input):
    with open(input, encoding='utf-8', newline='' ) as f:
        csvreader = csv.reader(f)
        l = [row for row in csvreader]
        return l

def create_dataset_csv(input, output):
    #データセットの生成（各ニュース記事のタイトルを取得）
    df = pd.DataFrame(columns=['label', 'sentence'])
    utter_list = get_utter_list(input)
    for utter in utter_list:
        if len(utter) == 0:
            continue
        df = pd.concat([df, pd.DataFrame([{'label':int(utter[0]), 'sentence':utter[1]}])], ignore_index=True)

    #データをシャッフルする
    df = df.sample(frac=1)

    #学習用、検証用ファイル
    train = os.path.join(output, 'train.csv')
    val = os.path.join(output, 'val.csv')

    #上記で取得したデータを学習用と検証用に分割する
    num = len(df)
    df[:int(num*0.8)].to_csv(train, sep=',', index=False)
    df[int(num*0.8):].to_csv(val, sep=',', index=False)

def create_dataset_main():
    create_dataset_csv('data/list.csv', 'data/')

if __name__ == '__main__':
    create_dataset_main()